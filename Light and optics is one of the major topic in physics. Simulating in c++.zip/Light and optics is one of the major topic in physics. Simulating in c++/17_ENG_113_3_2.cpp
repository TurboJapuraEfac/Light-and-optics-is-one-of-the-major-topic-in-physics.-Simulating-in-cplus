#include <iostream>
#include <ctime> 
#include <cstdlib> //library to use rand function

using namespace  std;

int main()
{
	int exitFromSurf = 0;
	int range = 100000;

	for (int k = 0; k <= 1; k++)
	{
		for (int i = 1; i < range; i++)
		{
			int photons = rand() % 10000 + 1;//generate a random number between 1 to 10000
			if (photons > 100)//enters in to glass
			{
				int photons = rand() % 10000 + 1;
				if (photons > 50)//goes to exiting surface
				{
					int photons = rand() % 10000 + 1;//Assume  paint was a seperate medium

					if (photons > 10)// goes through glass exitingsurface
					{
						int photons = (rand() % 10000) + 1;
						if (photons > 100)// reflected back by the paint
						{
							int photons = (rand() % 10000) + 1;
							if (photons > 100)//hits the glass surface again	
							{
								int photons = (rand() % 10000) + 1;
								if (photons > 50)//absorbtion
								{
									int photons = (rand() % 10000) + 1;
									if (photons > 1)
									{
										exitFromSurf++;
									}
								}
							}
						}

					}
				}

			}
			

		}
		cout << endl << endl << "If " << range << " photons enter in to the medium" << endl;
		cout << exitFromSurf << " photons exit from the medium entering surface \ndue to reflection occurred in the second surface";
		exitFromSurf = 0;
		range = 1000000;

	}





	system("pause");
	return 0;
}