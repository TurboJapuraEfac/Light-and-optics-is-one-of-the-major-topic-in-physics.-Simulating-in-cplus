#include <iostream>
#include <ctime> 
#include <cstdlib> //library to use rand function

using namespace  std;

int main()
{
	int photons = 1000000, Exit = 0;

	for (int i = 0; i < photons; i++)
	{
		bool notAbsorbedOuterL1 = (rand() % 100 < 90),
	    notReflectedOuterL1 = (rand() % 100 < 95),
		notReflectedInnerL1 = (rand() % 100 < 97),
		notAbsorbedOuterL2 = (rand() % 100 < 90),
		notReflectedOuterL2 = (rand() % 100 < 95),
		notReflectedInnerL2 = (rand() % 100 < 97),
		notAbsorbedOuterL3 = (rand() % 100 < 90),
		notReflectedOuterL3 = (rand() % 100 < 95),
		notReflectedInnerL3 = (rand() % 100 < 97),
		passL1 = ((rand() % 6) / 6.0 < sin(20)),
	    passL2 = ((rand() % 4) / 4.0 < sin(20)),
		passL3 = ((rand() % 6) / 6.0 < sin(20));

		//check whether the photon has pass the layer 1
		if (passL1)
		{
			//check the photon has absorbed in outer layer1
			if (notAbsorbedOuterL1) 
			{
				//check whether the photon reflected in outer layer1
				if (notReflectedOuterL1) 
				{
					//check whether the photon reflected in inner layer1
					if (notReflectedInnerL1) 
					{
						//check whether the photon pass the layer 2
						if (passL2) 
						{
							//check whether the photon is absorbed in outer layer2
							if (notAbsorbedOuterL2) 
							{
								//check whether  the photon reflected in outer layer2
								if (notReflectedOuterL2) 
								{
									//checking the photon reflected in inner layer 2
									if (notReflectedInnerL2) 
									{
										//checking the photon pass the layer 3
										if (passL3)
										{
											if (notAbsorbedOuterL3) 
											{
												if (notReflectedOuterL3)
												{
													if (notReflectedInnerL3) 
													{
														Exit++;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	//presenting the count of exiting photons as a percentage
	float precentages = ((float)Exit / photons) * 100;

	cout << " percentage of light that pass through the structure :" << precentages << endl;


	system("pause");
	return 0;
}