#include <iostream>
#include <ctime> 
#include <cstdlib> //library to use rand function

using namespace  std;

int main()
{
	int  entertoMed1 = 0;
	int  entertoMed2 = 0;

	int  exitingMed1 = 0;
	int  exitingMed2 = 0;

	int  exitMed1 = 0;
	int  exitMed2 = 0;

	int  absorbedMed1 = 0;
	int  absorbedMed2 = 0;

	int  simulations = 10000;

	for (int i = 1; i < 1000001; i++)
	{
		int photons = (rand() % 10000) + 1;
		if (photons > 100)// enter in to the glass
		{
			int photons = (rand() % 10000) + 1;
			if (photons > 75)// goes to the exiting surface without absorbing
			{
				int photons = (rand() % 10000) + 1;
				if (photons > 10)// exited medium 1
				{
					exitMed1++;

					int photons = (rand() % 10000) + 1;
					if (photons > 50)// entered medium 2
					{
						int photons = (rand() % 10000) + 1;
						if (photons > 50)//goes to the exiting surface without absorbing 
						{
							int photons = (rand() % 10000) + 1;
							if (photons == 1)//photons reflected back by exiting surface of medium 2
								exitingMed2++;
							else
								exitMed2++;
						}
						else
						{
							absorbedMed2++;
						}
					}
					else
					{
						entertoMed2++;
					}
				}
				else
				{
					exitingMed1++;
				}
			}
			else
			{
				absorbedMed1++;
			}
		}
		else
		{
			entertoMed1++;
		}
		if (i == simulations)
		{
			cout << endl<<endl << " Simulations from " << i - 10000 << " to " << i << " range"<<endl<<endl;
			cout << " MEDIUM 1 details" << endl;
			cout << " Photons reflceted when entering : " << entertoMed1 << endl;
			cout << " Photons reflected when exiting  : " << exitingMed1<< endl;
			cout << " Photons absorbed              : " << absorbedMed1 << endl;
			cout << " photons exit the medium       : " << exitingMed1 << endl<<endl<<endl;

			cout << endl << " MEDIUM 2" << endl;
			cout << " Photons reflceted when entering : " << entertoMed1 << endl;
			cout << " Photons reflected when exiting  : " << exitingMed1 << endl;
			cout << " Photons absorbed              : " << absorbedMed1 << endl;
			cout << " photons exit the medium       : " << exitingMed1 << endl << endl << endl;

			simulations += 10000;
			
			 entertoMed1 = 0;
			 entertoMed2 = 0;

			 exitingMed1 = 0;
		     exitingMed2 = 0;

			 exitMed1 = 0;
			 exitMed2 = 0;

			 absorbedMed1 = 0;
			 absorbedMed2 = 0;

		}
	}

	system("pause");
	return 0;
}