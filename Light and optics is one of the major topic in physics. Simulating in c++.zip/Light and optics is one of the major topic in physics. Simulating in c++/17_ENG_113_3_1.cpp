#include <iostream>
#include <ctime> 
#include <cstdlib> //library to use rand function

using namespace  std;


int main()
{
	cout << " Please enter the proton range that you want..." << endl;
	cout << " It should be either 10001,100001,1000001..." << endl;
	unsigned int protonRange;
	cout << " This is your input:";//user has to enter the range manually
	cin >> protonRange;

	int enter = 0,exitsurf = 0, exitglass =0,absorb = 0;//these are icremented if condition is true
	int simulations = 10000; 
	for (int i = 0; i < protonRange; i++)
	{
		int photons = rand() % 10000 + 1;//generate a random number between 1 to 10000
		if (photons > 100)//enters in to glass
		{
			int photons = rand() % 10000 + 1;
			if (photons > 50)//goes to exiting surface
			{
				int protons = rand() % 10000 + 1;
				if (protons == 1)//reflected from exiting surface
				{
					exitsurf++;
				}
				else  //travelled through glass
				{
					exitglass++;
				}
			}
			else
			{
				absorb++;
			}

		}
		else
		{
			enter++;
		}

		if (i == simulations)//print answers in to console for every 10000 simulations
		{
			cout << endl << endl << " Simulations from " << i - 10000 << " to " << i << " range"<<endl;
			cout << " Photons reflect on the Entering surface = " << enter << endl;
			cout << " Photons reflect on the Exiting surface = " << exitsurf << endl;
			cout << " Photons absorbed to the Glass = " << absorb << endl;
			cout << " Photons exited from the Glass = " << exitglass << endl;
			simulations += 10000;
		}



	}

	system("pause");
	return 0;
}