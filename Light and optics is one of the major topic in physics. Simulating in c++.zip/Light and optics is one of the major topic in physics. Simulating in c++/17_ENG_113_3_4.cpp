#include <iostream>
#include <ctime> 
#include <cstdlib> //library to use rand function

using namespace  std;

int main()
{
	int exitMed1=0,paintReflect = 0,reflectBack = 0,simulations = 100000;
	for (int i = 1; i < 10000001; i++)
	{
		int photons = (rand() % 10000) + 1;
		if (photons > 100) //enters the glass
		{
			int photons = (rand() % 10000) + 1;
			if (photons > 75)//goes to the exiting surface without absorbing
			{
				int photons = (rand() % 10000) + 1;
				if (photons > 10)
				{
					exitMed1++;
					int photons = (rand() % 10000) + 1;
					if (photons > 50)
					{
						int photons = (rand() % 10000) + 1;
						if (photons > 50)
						{
							int photons = (rand() % 10000) + 1;
							if (photons > 1)
							{
								//glass and paint considered as two seperate mediums

								int photon = (rand() % 10000) + 1;
								if (photon > 500)//paint reflect
								{
									paintReflect++;

									int photons = (rand() % 10000) + 1;
									if (photons > 50)
									{
										int photon = (rand() % 10000) + 1;
										if (photon > 50)//absorb
										{
											int photon = (rand() % 10000) + 1;
											if (photon > 1)// enter medium 1
											{
												reflectBack++;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		if (i == simulations)
		{
			cout << endl <<endl<< " Simulation of  " << i - 100000 << " to " << i << " range"<<endl;
			cout << " Number of photons reflected from the paint : " << paintReflect << endl;
			cout << " Number of photons re-entered the medium 1 from medium 2 : " << reflectBack << endl;
			cout << " Number of photons exit form the medium 1 : " << exitMed1 << endl;
			simulations += 10000;
		}
	}



	system("pause");
	return 0;
}